package com.macrostudio;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.Consumer;

public class MacroStudioScreen extends Screen {
	private enum Mode { MACROS, BINDS, KEYS }

	private static final int ACCENT = 0xFF4FC3F7;
	private static final int TEXT = 0xFFE6E8EE;
	private static final int MUTED = 0xFF8A90A0;

	private Mode mode = Mode.MACROS;
	private String selected;
	private int page = 0;
	private int bindPage = 0;
	private String renameText = "";
	private String captureId = null;
	private Consumer<Integer> capture = null;
	private int px, py, pw, ph;

	public MacroStudioScreen() {
		super(Component.literal("Macro Studio"));
	}

	@Override
	protected void init() {
		rebuild();
	}

	@Override
	public void removed() {
		Settings.save();
	}

	private Button btn(String text, int x, int y, int w, int h, Button.OnPress press) {
		Button b = Button.builder(Component.literal(text), press).bounds(x, y, w, h).build();
		addRenderableWidget(b);
		return b;
	}

	private String keyLabel(String id, String prefix, int code) {
		if (id.equals(captureId)) return prefix + "нажми клавишу...";
		return prefix + (code < 0 ? "не задана" : Keys.name(code));
	}

	private void startCapture(String id, Consumer<Integer> onKey) {
		captureId = id;
		capture = onKey;
		rebuild();
	}

	private void rebuild() {
		clearWidgets();
		pw = Math.min(width - 16, 440);
		ph = height - 16;
		px = (width - pw) / 2;
		py = 8;

		btn("Закрыть", px + pw - 66, py + 5, 60, 16, b -> onClose());
		btn("Записи", px + 8, py + 24, 80, 18, b -> {
			mode = Mode.MACROS;
			rebuild();
		});
		btn("Бинды", px + 92, py + 24, 80, 18, b -> {
			mode = Mode.BINDS;
			rebuild();
		});
		btn("Клавиши", px + 176, py + 24, 80, 18, b -> {
			mode = Mode.KEYS;
			rebuild();
		});

		switch (mode) {
			case MACROS -> buildMacros();
			case BINDS -> buildBinds();
			case KEYS -> buildKeys();
		}
	}

	// ---------------- macros ----------------

	private void buildMacros() {
		List<String> names = Macros.list();
		if (selected != null && !names.contains(selected)) selected = null;
		int y0 = py + 48;
		int lw = (int) (pw * 0.45f);
		int rows = Math.max(1, (ph - 48 - 30) / 22);
		int pages = Math.max(1, (names.size() + rows - 1) / rows);
		page = Math.max(0, Math.min(page, pages - 1));
		for (int i = 0; i < rows; i++) {
			int idx = page * rows + i;
			if (idx >= names.size()) break;
			String n = names.get(idx);
			Integer k = Settings.I.macroKeys.get(n);
			String label = (n.equals(selected) ? "> " : "") + (n.length() > 16 ? n.substring(0, 16) + ".." : n)
					+ (k != null && k >= 0 ? "  [" + Keys.name(k) + "]" : "");
			btn(label, px + 8, y0 + i * 22, lw, 20, b -> {
				selected = n;
				renameText = "";
				rebuild();
			});
		}
		int by = py + ph - 24;
		btn("<", px + 8, by, 30, 18, b -> {
			page = Math.max(0, page - 1);
			rebuild();
		});
		btn(">", px + 8 + lw - 30, by, 30, 18, b -> {
			page++;
			rebuild();
		});

		int rx = px + lw + 16;
		int rw = pw - lw - 24;
		btn(Recorder.active ? "Остановить запись" : "Начать запись", rx, y0, rw, 20, b -> {
			if (Recorder.active) {
				Recorder.stop();
				rebuild();
			} else {
				onClose();
				Recorder.start();
			}
		});
		if (selected == null) return;
		final String sel = selected;
		int half = (rw - 4) / 2;
		btn("Играть", rx, y0 + 26, half, 20, b -> {
			onClose();
			Replayer.play(Macros.load(sel), false);
		});
		btn("В цикле", rx + half + 4, y0 + 26, half, 20, b -> {
			onClose();
			Replayer.play(Macros.load(sel), true);
		});
		btn("Остановить", rx, y0 + 48, rw, 20, b -> {
			Replayer.stop();
			Recorder.stop();
			rebuild();
		});
		int cur = Settings.I.macroKeys.getOrDefault(sel, -1);
		btn(keyLabel("mk", "Клавиша: ", cur), rx, y0 + 70, rw, 20, b -> startCapture("mk", code -> {
			if (code < 0) Settings.I.macroKeys.remove(sel);
			else Settings.I.macroKeys.put(sel, code);
			Settings.save();
		}));
		EditBox eb = new EditBox(font, rx, y0 + 92, rw - 34, 18, Component.literal("name"));
		eb.setMaxLength(32);
		eb.setValue(renameText.isEmpty() ? sel : renameText);
		eb.setResponder(s -> renameText = s);
		addRenderableWidget(eb);
		btn("OK", rx + rw - 30, y0 + 92, 30, 18, b -> {
			String n = Macros.sanitize(renameText.isEmpty() ? sel : renameText);
			if (!n.isEmpty() && Macros.rename(sel, n)) selected = n;
			renameText = "";
			rebuild();
		});
		btn("Удалить", rx, y0 + 114, rw, 20, b -> {
			Macros.delete(sel);
			Settings.save();
			selected = null;
			rebuild();
		});
	}

	// ---------------- binds ----------------

	private void buildBinds() {
		int y0 = py + 48;
		int rows = Math.max(1, (ph - 48 - 52) / 24);
		List<Settings.Bind> binds = Settings.I.binds;
		int pages = Math.max(1, (binds.size() + rows - 1) / rows);
		bindPage = Math.max(0, Math.min(bindPage, pages - 1));
		for (int i = 0; i < rows; i++) {
			int idx = bindPage * rows + i;
			if (idx >= binds.size()) break;
			Settings.Bind bd = binds.get(idx);
			int y = y0 + i * 24;
			btn(keyLabel("b" + idx, "", bd.key), px + 8, y, 90, 20, b -> startCapture("b" + idx, code -> {
				bd.key = code;
				Settings.save();
			}));
			EditBox eb = new EditBox(font, px + 102, y + 1, pw - 102 - 8 - 24, 18, Component.literal("cmd"));
			eb.setMaxLength(200);
			eb.setValue(bd.lines == null ? "" : bd.lines);
			eb.setResponder(s -> bd.lines = s);
			addRenderableWidget(eb);
			btn("X", px + pw - 28, y, 20, 20, b -> {
				binds.remove(bd);
				Settings.save();
				rebuild();
			});
		}
		int by = py + ph - 44;
		btn("+ Добавить", px + 8, by, 100, 18, b -> {
			binds.add(new Settings.Bind());
			bindPage = (binds.size() - 1) / rows;
			Settings.save();
			rebuild();
		});
		btn("<", px + pw - 70, by, 30, 18, b -> {
			bindPage = Math.max(0, bindPage - 1);
			rebuild();
		});
		btn(">", px + pw - 38, by, 30, 18, b -> {
			bindPage++;
			rebuild();
		});
	}

	// ---------------- global keys ----------------

	private void buildKeys() {
		int y0 = py + 52;
		int w = Math.min(pw - 16, 260);
		btn(keyLabel("open", "Открыть это окно: ", Settings.I.openKey), px + 8, y0, w, 20,
				b -> startCapture("open", c -> Settings.I.openKey = c < 0 ? 345 : c));
		btn(keyLabel("rec", "Старт/стоп записи: ", Settings.I.recordKey), px + 8, y0 + 26, w, 20,
				b -> startCapture("rec", c -> Settings.I.recordKey = c));
		btn(keyLabel("stop", "Остановить всё: ", Settings.I.stopKey), px + 8, y0 + 52, w, 20,
				b -> startCapture("stop", c -> Settings.I.stopKey = c));
	}

	// ---------------- input ----------------

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = event.key();
		if (capture != null) {
			Consumer<Integer> c = capture;
			capture = null;
			captureId = null;
			if (key != 256) {
				c.accept(key == 259 || key == 261 ? -1 : key);
				Settings.save();
			}
			rebuild();
			return true;
		}
		if (key == Settings.I.openKey && !(getFocused() instanceof EditBox)) {
			onClose();
			return true;
		}
		return super.keyPressed(event);
	}

	// ---------------- drawing ----------------

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		g.fill(0, 0, width, height, 0xB0000000);
		g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF2B3140);
		g.fill(px, py, px + pw, py + ph, 0xF012151C);
		g.fill(px, py, px + pw, py + 21, 0xFF1B2030);
		g.fill(px, py + 21, px + pw, py + 22, ACCENT);
		if (mode == Mode.MACROS) {
			int lw = (int) (pw * 0.45f);
			g.fill(px + 4, py + 46, px + 12 + lw, py + ph - 28, 0x40000000);
		}
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		super.render(g, mouseX, mouseY, partialTick);
		g.drawString(font, "Macro Studio", px + 8, py + 7, ACCENT);
		String st = Recorder.active ? "ИДЁТ ЗАПИСЬ" : Replayer.active ? "Играет: " + Replayer.currentName() : "";
		if (!st.isEmpty()) g.drawString(font, st, px + 100, py + 7, 0xFFFF6B6B);

		int hintY = py + ph - 12;
		switch (mode) {
			case MACROS -> {
				if (Macros.list().isEmpty()) {
					g.drawString(font, "Записей пока нет", px + 14, py + 54, MUTED);
					g.drawString(font, "Нажми «Начать запись»", px + 14, py + 66, MUTED);
				}
				if (selected == null) {
					int lw = (int) (pw * 0.45f);
					g.drawString(font, "Выбери запись слева", px + lw + 16, py + 48 + 30, MUTED);
				}
			}
			case BINDS -> g.drawString(font, "Пример: /warp mine ;; wait 2s ;; /home   (пусто = клавиша не работает)", px + 8, hintY, MUTED);
			case KEYS -> {
				g.drawString(font, "Backspace при выборе — очистить. Esc — отмена.", px + 8, py + 52 + 82, MUTED);
				g.drawString(font, "По умолчанию кроме окна всё пусто.", px + 8, py + 52 + 94, MUTED);
			}
		}
		if (captureId != null) g.drawString(font, "Нажми нужную клавишу (Alt, Ctrl — тоже можно)", px + 8, hintY - 12, 0xFFFFD54F);
	}
}
