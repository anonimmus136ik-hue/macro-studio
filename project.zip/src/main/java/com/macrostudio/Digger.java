package com.macrostudio;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Digs a rectangle (set by two points) down to a given depth, following the real terrain:
 * the surface height is measured separately for every column, so hills and steps are fine.
 * The bot walks over the area in a snake pattern and mines the columns behind it,
 * so the block under its feet and the path ahead stay solid. Real chasms are skipped,
 * narrow ones are jumped over.
 */
public final class Digger {
	public static boolean active = false;
	/** Set by the auto-deposit while the bot is away. */
	public static boolean paused = false;

	private static final double REACH = 4.3;
	private static final int NONE = Integer.MIN_VALUE;

	private static List<int[]> path = new ArrayList<>();
	private static final Map<Integer, Integer> topCache = new HashMap<>();
	private static int idx;
	private static int refY;
	private static int depth;
	private static BlockPos target;
	private static int mineTicks;
	private static final Set<BlockPos> skip = new HashSet<>();

	private Digger() {
	}

	public static void setPoint(Minecraft mc, int which) {
		if (mc.player == null) return;
		BlockPos p = mc.player.blockPosition();
		int[] v = new int[] { p.getX(), p.getY(), p.getZ() };
		if (which == 1) Settings.I.dig1 = v;
		else Settings.I.dig2 = v;
		Settings.save();
	}

	public static void start(Minecraft mc) {
		Settings s = Settings.I;
		if (mc.player == null) return;
		if (s.dig1 == null || s.dig2 == null) {
			Recorder.msg("Сначала задай обе точки");
			return;
		}
		if (Replayer.active) Replayer.stop();
		int minX = Math.min(s.dig1[0], s.dig2[0]);
		int maxX = Math.max(s.dig1[0], s.dig2[0]);
		int minZ = Math.min(s.dig1[2], s.dig2[2]);
		int maxZ = Math.max(s.dig1[2], s.dig2[2]);
		refY = Math.max(s.dig1[1], s.dig2[1]);
		depth = Math.max(1, Math.min(8, s.digDepth));
		path = new ArrayList<>();
		int row = 0;
		for (int z = minZ; z <= maxZ; z++, row++) {
			if (row % 2 == 0) for (int x = minX; x <= maxX; x++) path.add(new int[] { x, z });
			else for (int x = maxX; x >= minX; x--) path.add(new int[] { x, z });
		}
		topCache.clear();
		idx = 0;
		target = null;
		mineTicks = 0;
		skip.clear();
		paused = false;
		active = true;
		Recorder.msg("Копатель запущен: " + path.size() + " клеток, глубина " + depth);
	}

	public static void stop() {
		if (!active) return;
		active = false;
		paused = false;
		releaseKeys(Minecraft.getInstance());
		Recorder.msg("Копатель остановлен");
	}

	public static void releaseKeys(Minecraft mc) {
		if (mc.options == null) return;
		mc.options.keyAttack.setDown(false);
		mc.options.keyUp.setDown(false);
		mc.options.keyJump.setDown(false);
		mc.options.keySprint.setDown(false);
	}

	private static void say(Minecraft mc, String text) {
		if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Macro Studio] " + text), false);
	}

	private static boolean walkable(BlockState st) {
		return st.blocksMotion() && !st.is(BlockTags.LEAVES);
	}

	/** Surface height of a column, measured once (before the bot touches it). */
	private static int topOf(Minecraft mc, int i) {
		Integer c = topCache.get(i);
		if (c != null) return c;
		int[] cell = path.get(i);
		int v = NONE;
		for (int y = refY + 3; y >= refY - 8; y--) {
			if (walkable(mc.level.getBlockState(new BlockPos(cell[0], y, cell[1])))) {
				v = y;
				break;
			}
		}
		topCache.put(i, v);
		return v;
	}

	public static void tick(Minecraft mc) {
		if (!active) return;
		if (mc.player == null || mc.level == null) {
			active = false;
			return;
		}
		if (paused || mc.screen != null) {
			releaseKeys(mc);
			return;
		}
		int cur = Math.min(idx, path.size() - 1);
		int curTop = topOf(mc, cur);
		if (curTop != NONE && mc.player.getY() < curTop + 1 - 2.5) {
			say(mc, "Копатель: бот провалился. y=" + String.format("%.1f", mc.player.getY()) + ", поверхность здесь y=" + curTop);
			stop();
			return;
		}

		if (target != null && mc.level.getBlockState(target).isAir()) {
			target = null;
			mineTicks = 0;
		}
		if (target == null) target = findTarget(mc);
		if (target != null) {
			mc.options.keyUp.setDown(false);
			mc.options.keyJump.setDown(false);
			mc.options.keySprint.setDown(false);
			aim(mc, target);
			mc.options.keyAttack.setDown(true);
			if (++mineTicks > 80) {
				skip.add(target);
				target = null;
				mineTicks = 0;
			}
			return;
		}
		mc.options.keyAttack.setDown(false);

		int[] cell = path.get(cur);
		double dx = cell[0] + 0.5 - mc.player.getX();
		double dz = cell[1] + 0.5 - mc.player.getZ();
		if (Math.sqrt(dx * dx + dz * dz) < 0.3) {
			mc.options.keyUp.setDown(false);
			mc.options.keyJump.setDown(false);
			mc.options.keySprint.setDown(false);
			int next = idx + 1;
			int holes = 0;
			while (next < path.size() && topOf(mc, next) == NONE) {
				next++;
				holes++;
			}
			if (next >= path.size()) {
				stop();
				Recorder.msg("Копатель закончил");
				return;
			}
			if (holes >= 3) {
				int[] hc = path.get(idx + 1);
				say(mc, "Копатель: " + holes + " клеток подряд без земли, начиная с x=" + hc[0] + " z=" + hc[1]);
				stop();
				return;
			}
			idx = next;
			return;
		}
		float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
		mc.player.setYRot(yaw);
		mc.player.setXRot(15f);
		mc.options.keyUp.setDown(true);

		double rad = Math.toRadians(yaw);
		int ax = (int) Math.floor(mc.player.getX() - Math.sin(rad) * 0.9);
		int az = (int) Math.floor(mc.player.getZ() + Math.cos(rad) * 0.9);
		int gy = (int) Math.floor(mc.player.getY());
		boolean chasm = !walkable(mc.level.getBlockState(new BlockPos(ax, gy - 1, az)))
				&& !walkable(mc.level.getBlockState(new BlockPos(ax, gy - 2, az)));
		mc.options.keySprint.setDown(chasm);
		mc.options.keyJump.setDown(chasm || mc.player.horizontalCollision);
	}

	private static BlockPos findTarget(Minecraft mc) {
		Vec3 eye = mc.player.getEyePosition();
		for (int i = Math.min(idx, path.size()) - 1; i >= Math.max(0, idx - 12); i--) {
			int top = topOf(mc, i);
			if (top == NONE) continue;
			int[] c = path.get(i);
			for (int y = top; y > top - depth; y--) {
				BlockPos p = new BlockPos(c[0], y, c[1]);
				if (skip.contains(p)) continue;
				if (mc.level.getBlockState(p).isAir()) continue;
				Vec3 ctr = new Vec3(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
				if (ctr.distanceTo(eye) <= REACH) return p;
			}
		}
		return null;
	}

	private static void aim(Minecraft mc, BlockPos p) {
		Vec3 eye = mc.player.getEyePosition();
		double dx = p.getX() + 0.5 - eye.x;
		double dy = p.getY() + 0.5 - eye.y;
		double dz = p.getZ() + 0.5 - eye.z;
		mc.player.setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
		mc.player.setXRot((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))));
	}
}
