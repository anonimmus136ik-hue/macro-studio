package com.macrostudio;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Digs a rectangle (set by two points) down to a given depth.
 * The bot walks over the area in a snake pattern and mines the columns behind it,
 * so the block under its feet and the path ahead stay solid. Holes in the surface are
 * skipped, narrow ones are jumped over.
 */
public final class Digger {
	public static boolean active = false;
	/** Set by the auto-deposit while the bot is away. */
	public static boolean paused = false;

	private static final double REACH = 4.3;

	private static List<int[]> path = new ArrayList<>();
	private static int idx;
	private static int yTop;
	private static int depth;
	private static BlockPos target;
	private static int mineTicks;
	private static final Set<BlockPos> skip = new HashSet<>();

	private Digger() {
	}

	public static void setPoint(Minecraft mc, int which) {
		if (mc.player == null) return;
		BlockPos p = mc.player.blockPosition();
		int[] v = new int[] { p.getX(), p.getY(), p.getZ() };
		if (which == 1) Settings.I.dig1 = v;
		else Settings.I.dig2 = v;
		Settings.save();
	}

	public static void start(Minecraft mc) {
		Settings s = Settings.I;
		if (mc.player == null) return;
		if (s.dig1 == null || s.dig2 == null) {
			Recorder.msg("Сначала задай обе точки");
			return;
		}
		if (Replayer.active) Replayer.stop();
		int minX = Math.min(s.dig1[0], s.dig2[0]);
		int maxX = Math.max(s.dig1[0], s.dig2[0]);
		int minZ = Math.min(s.dig1[2], s.dig2[2]);
		int maxZ = Math.max(s.dig1[2], s.dig2[2]);
		yTop = Math.min(s.dig1[1], s.dig2[1]) - 1;
		depth = Math.max(1, Math.min(8, s.digDepth));
		path = new ArrayList<>();
		int row = 0;
		for (int z = minZ; z <= maxZ; z++, row++) {
			if (row % 2 == 0) for (int x = minX; x <= maxX; x++) path.add(new int[] { x, z });
			else for (int x = maxX; x >= minX; x--) path.add(new int[] { x, z });
		}
		idx = 0;
		target = null;
		mineTicks = 0;
		skip.clear();
		paused = false;
		active = true;
		Recorder.msg("Копатель запущен: " + path.size() + " клеток, глубина " + depth);
	}

	public static void stop() {
		if (!active) return;
		active = false;
		paused = false;
		releaseKeys(Minecraft.getInstance());
		Recorder.msg("Копатель остановлен");
	}

	public static void releaseKeys(Minecraft mc) {
		if (mc.options == null) return;
		mc.options.keyAttack.setDown(false);
		mc.options.keyUp.setDown(false);
		mc.options.keyJump.setDown(false);
		mc.options.keySprint.setDown(false);
	}

	private static boolean hole(Minecraft mc, int[] c) {
		return mc.level.getBlockState(new BlockPos(c[0], yTop, c[1])).isAir();
	}

	public static void tick(Minecraft mc) {
		if (!active) return;
		if (mc.player == null || mc.level == null) {
			active = false;
			return;
		}
		if (paused || mc.screen != null) {
			releaseKeys(mc);
			return;
		}
		if (mc.player.getY() < yTop + 1 - 1.5) {
			stop();
			Recorder.msg("Копатель остановлен: бот упал вниз");
			return;
		}

		if (target != null && mc.level.getBlockState(target).isAir()) {
			target = null;
			mineTicks = 0;
		}
		if (target == null) target = findTarget(mc);
		if (target != null) {
			mc.options.keyUp.setDown(false);
			mc.options.keyJump.setDown(false);
			mc.options.keySprint.setDown(false);
			aim(mc, target);
			mc.options.keyAttack.setDown(true);
			if (++mineTicks > 80) {
				skip.add(target);
				target = null;
				mineTicks = 0;
			}
			return;
		}
		mc.options.keyAttack.setDown(false);

		int[] cell = path.get(Math.min(idx, path.size() - 1));
		double dx = cell[0] + 0.5 - mc.player.getX();
		double dz = cell[1] + 0.5 - mc.player.getZ();
		if (Math.sqrt(dx * dx + dz * dz) < 0.3) {
			mc.options.keyUp.setDown(false);
			mc.options.keyJump.setDown(false);
			mc.options.keySprint.setDown(false);
			int next = idx + 1;
			int holes = 0;
			while (next < path.size() && hole(mc, path.get(next))) {
				next++;
				holes++;
			}
			if (next >= path.size()) {
				stop();
				Recorder.msg("Копатель закончил");
				return;
			}
			if (holes >= 3) {
				stop();
				Recorder.msg("Копатель остановлен: дыра слишком широкая");
				return;
			}
			idx = next;
			return;
		}
		float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
		mc.player.setYRot(yaw);
		mc.player.setXRot(15f);
		mc.options.keyUp.setDown(true);

		double rad = Math.toRadians(yaw);
		double ax = mc.player.getX() - Math.sin(rad) * 0.9;
		double az = mc.player.getZ() + Math.cos(rad) * 0.9;
		boolean holeAhead = mc.level.getBlockState(new BlockPos((int) Math.floor(ax), yTop, (int) Math.floor(az))).isAir();
		mc.options.keySprint.setDown(holeAhead);
		mc.options.keyJump.setDown(holeAhead || mc.player.horizontalCollision);
	}

	private static BlockPos findTarget(Minecraft mc) {
		Vec3 eye = mc.player.getEyePosition();
		for (int i = Math.min(idx, path.size()) - 1; i >= Math.max(0, idx - 12); i--) {
			int[] c = path.get(i);
			for (int y = yTop; y > yTop - depth; y--) {
				BlockPos p = new BlockPos(c[0], y, c[1]);
				if (skip.contains(p)) continue;
				if (mc.level.getBlockState(p).isAir()) continue;
				Vec3 ctr = new Vec3(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
				if (ctr.distanceTo(eye) <= REACH) return p;
			}
		}
		return null;
	}

	private static void aim(Minecraft mc, BlockPos p) {
		Vec3 eye = mc.player.getEyePosition();
		double dx = p.getX() + 0.5 - eye.x;
		double dy = p.getY() + 0.5 - eye.y;
		double dz = p.getZ() + 0.5 - eye.z;
		mc.player.setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
		mc.player.setXRot((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))));
	}
}
