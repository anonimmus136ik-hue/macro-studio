package com.macrostudio;

import com.macrostudio.mixin.ScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/** Hold Shift + left mouse and drag over slots: every slot you touch is quick-moved (like Mouse Tweaks). */
public final class DragMove {
	private static final Set<Integer> DONE = new HashSet<>();
	private static boolean started = false;

	private DragMove() {
	}

	public static void tick(Minecraft mc) {
		if (!Settings.I.dragMove || mc.player == null || mc.gameMode == null
				|| !(mc.screen instanceof AbstractContainerScreen<?> scr)) {
			DONE.clear();
			started = false;
			return;
		}
		long h = mc.getWindow().handle();
		boolean down = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		boolean shift = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
				|| GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
		if (!down || !shift) {
			DONE.clear();
			started = false;
			return;
		}
		Slot s = slotAt(mc, scr);
		if (s == null) return;
		if (!started) {
			// the first slot was already handled by the game itself
			started = true;
			DONE.add(s.index);
			return;
		}
		if (!DONE.add(s.index)) return;
		if (!s.hasItem()) return;
		mc.gameMode.handleInventoryMouseClick(scr.getMenu().containerId, s.index, 0, ClickType.QUICK_MOVE, mc.player);
	}

	private static Slot slotAt(Minecraft mc, AbstractContainerScreen<?> scr) {
		double mx = mc.mouseHandler.xpos() * mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
		double my = mc.mouseHandler.ypos() * mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();
		ScreenAccessor a = (ScreenAccessor) (Object) scr;
		int l = a.macrostudio$left();
		int t = a.macrostudio$top();
		for (Slot s : scr.getMenu().slots) {
			if (mx >= l + s.x && mx < l + s.x + 16 && my >= t + s.y && my < t + s.y + 16) return s;
		}
		return null;
	}
}
