package com.macrostudio.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AbstractContainerScreen.class)
public interface ScreenAccessor {
	@Accessor("leftPos")
	int macrostudio$left();

	@Accessor("topPos")
	int macrostudio$top();
}
