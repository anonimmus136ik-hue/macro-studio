package com.macrostudio;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Settings {
	/** GLFW_KEY_RIGHT_CONTROL */
	public int openKey = 345;
	public int recordKey = -1;
	public int stopKey = -1;
	public Map<String, Integer> macroKeys = new LinkedHashMap<>();
	public List<Bind> binds = new ArrayList<>();

	public static final class Bind {
		public int key = -1;
		public String lines = "";
	}

	public static Settings I = new Settings();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static Path dir() {
		return FabricLoader.getInstance().getConfigDir().resolve("macrostudio");
	}

	private static Path file() {
		return dir().resolve("settings.json");
	}

	public static void load() {
		try {
			Path f = file();
			if (Files.exists(f)) {
				Settings s = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), Settings.class);
				if (s != null) {
					if (s.macroKeys == null) s.macroKeys = new LinkedHashMap<>();
					if (s.binds == null) s.binds = new ArrayList<>();
					I = s;
				}
			}
		} catch (Exception e) {
			System.err.println("[MacroStudio] Could not load settings: " + e);
		}
	}

	public static void save() {
		try {
			Files.createDirectories(dir());
			Files.writeString(file(), GSON.toJson(I), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.err.println("[MacroStudio] Could not save settings: " + e);
		}
	}

	/** Keys that belong to the mod itself and must not be recorded. */
	public static Set<Integer> reservedKeys() {
		Set<Integer> r = new HashSet<>();
		r.add(I.openKey);
		r.add(I.recordKey);
		r.add(I.stopKey);
		r.addAll(I.macroKeys.values());
		return r;
	}
}
