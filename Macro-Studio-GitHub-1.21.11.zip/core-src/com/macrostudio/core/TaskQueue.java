package com.macrostudio.core;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Objects;
import java.util.Optional;

/** Sequential task queue. Never executes multiple tasks that could fight for player input. */
public final class TaskQueue {
    private final Deque<StudioTask> pending = new ArrayDeque<>();
    private StudioTask current;
    private boolean paused;
    private String lastFailure = "";
    public void enqueue(StudioTask task) { pending.addLast(Objects.requireNonNull(task)); }
    public Optional<String> activeTaskId() { return Optional.ofNullable(current).map(StudioTask::id); }
    public int pendingCount() { return pending.size() + (current == null ? 0 : 1); }
    public void setPaused(boolean value) { paused = value; }
    public boolean isPaused() { return paused; }
    public String lastFailure() { return lastFailure; }
    public void tick() {
        if (paused) return;
        if (current == null) current = pending.pollFirst();
        if (current == null) return;
        try {
            TaskState state = Objects.requireNonNull(current.tick());
            if (state == TaskState.COMPLETED) current = null;
            else if (state == TaskState.FAILED) {
                lastFailure = "Task reported failure: " + current.id();
                safelyCancel(current);
                current = null;
            }
        } catch (RuntimeException exception) {
            lastFailure = "Task " + current.id() + " threw " + exception.getClass().getSimpleName();
            safelyCancel(current);
            current = null;
        }
    }
    private static void safelyCancel(StudioTask task) {
        try { task.cancel(); } catch (RuntimeException ignored) { /* never block global stop */ }
    }
    public void cancelAll() {
        if (current != null) safelyCancel(current);
        current = null;
        while (!pending.isEmpty()) safelyCancel(pending.removeFirst());
        paused = false;
    }
}
