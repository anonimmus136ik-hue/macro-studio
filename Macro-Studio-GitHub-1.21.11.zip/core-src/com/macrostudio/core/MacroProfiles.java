package com.macrostudio.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Safe, basic profile-name storage. Macro content is not migrated by this class. */
public final class MacroProfiles {
    private final Path file;
    private final List<String> profiles = new ArrayList<>();
    public MacroProfiles(Path file) { this.file = Objects.requireNonNull(file); }
    public List<String> list() { return List.copyOf(profiles); }
    public boolean add(String name) {
        if (name == null || !name.matches("[A-Za-z0-9_-]{1,40}") || profiles.contains(name)) return false;
        profiles.add(name);
        return true;
    }
    public void load() throws IOException {
        profiles.clear();
        if (!Files.exists(file)) return;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) add(line.strip());
    }
    public void save() throws IOException {
        Path parent = file.toAbsolutePath().getParent();
        Files.createDirectories(parent);
        Path temp = Files.createTempFile(parent, "macro-profiles-", ".tmp");
        try {
            Files.write(temp, profiles, StandardCharsets.UTF_8);
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally { Files.deleteIfExists(temp); }
    }
}
