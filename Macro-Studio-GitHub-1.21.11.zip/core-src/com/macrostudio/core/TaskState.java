package com.macrostudio.core;
public enum TaskState { RUNNING, WAITING, COMPLETED, FAILED }
