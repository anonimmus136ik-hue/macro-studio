package com.macrostudio.core;

import java.util.List;

/** Feature registry, not functional Minecraft implementations. */
public final class ModuleCatalog {
    private ModuleCatalog() {}
    public enum Phase { FOUNDATION, PERFORMANCE, VISUALS, PREVIEWS, MACROS, AUTOMATION, UI }
    public record Entry(String id, Phase phase) {}
    public static final List<Entry> REQUESTED = List.of(
        new Entry("emergency_stop", Phase.FOUNDATION),
        new Entry("task_queue", Phase.FOUNDATION),
        new Entry("macro_debugger", Phase.FOUNDATION),
        new Entry("macro_profiles", Phase.FOUNDATION),
        new Entry("sodium_compatibility", Phase.PERFORMANCE),
        new Entry("entity_culling", Phase.PERFORMANCE),
        new Entry("particle_limiter", Phase.PERFORMANCE),
        new Entry("dynamic_fps", Phase.PERFORMANCE),
        new Entry("performance_profiler", Phase.PERFORMANCE),
        new Entry("chunk_update_budget", Phase.PERFORMANCE),
        new Entry("armor_hud", Phase.VISUALS),
        new Entry("custom_fog", Phase.VISUALS),
        new Entry("item_physics", Phase.VISUALS),
        new Entry("fullbright", Phase.VISUALS),
        new Entry("shulker_preview", Phase.PREVIEWS),
        new Entry("container_preview", Phase.PREVIEWS),
        new Entry("ghost_replay", Phase.MACROS),
        new Entry("loop_manager", Phase.MACROS),
        new Entry("path_recorder", Phase.MACROS),
        new Entry("waypoints", Phase.MACROS),
        new Entry("macro_conditions", Phase.MACROS),
        new Entry("auto_fish", Phase.AUTOMATION),
        new Entry("auto_farm", Phase.AUTOMATION),
        new Entry("auto_sort", Phase.AUTOMATION),
        new Entry("auto_refill", Phase.AUTOMATION),
        new Entry("auto_eat", Phase.AUTOMATION),
        new Entry("hud_editor", Phase.UI),
        new Entry("theme_manager", Phase.UI),
        new Entry("timeline_editor", Phase.UI),
        new Entry("route_editor", Phase.UI)
    );
}
