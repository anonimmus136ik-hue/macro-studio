package com.macrostudio.core;

/** Execute one logical step per client tick. Integrations must run on the client thread. */
public interface StudioTask {
    String id();
    TaskState tick();
    void cancel();
}
