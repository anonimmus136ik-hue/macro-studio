package com.macrostudio.core;

import java.util.HashMap;
import java.util.Map;

/** Tracks timings of own modules. No global Minecraft profiling is implied. */
public final class PerformanceProfiler {
    private final Map<String, Stats> stats = new HashMap<>();
    public long start() { return System.nanoTime(); }
    public void record(String moduleId, long startedAtNanos) {
        long duration = Math.max(0L, System.nanoTime() - startedAtNanos);
        stats.computeIfAbsent(moduleId, ignored -> new Stats()).accept(duration);
    }
    public Map<String, Snapshot> snapshot() {
        Map<String, Snapshot> result = new HashMap<>();
        stats.forEach((id, data) -> result.put(id, new Snapshot(data.count, data.total / Math.max(1, data.count), data.max)));
        return Map.copyOf(result);
    }
    public void clear() { stats.clear(); }
    private static final class Stats {
        long count, total, max;
        void accept(long nanos) { count++; total += nanos; max = Math.max(max, nanos); }
    }
    public record Snapshot(long samples, long avgNanos, long maxNanos) {}
}
