package com.macrostudio.core;

import java.util.Objects;

/** Call on client thread; callback must release synthetic held keys and pending screen interactions. */
public final class EmergencyStop {
    private final TaskQueue tasks;
    private final Runnable releaseInputs;
    public EmergencyStop(TaskQueue tasks, Runnable releaseInputs) {
        this.tasks = Objects.requireNonNull(tasks);
        this.releaseInputs = Objects.requireNonNull(releaseInputs);
    }
    public void stopEverything() {
        try { tasks.cancelAll(); } finally { releaseInputs.run(); }
    }
}
