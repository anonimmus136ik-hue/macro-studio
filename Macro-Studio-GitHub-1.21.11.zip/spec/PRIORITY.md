# Очередность разработки

1. Восстановить исходный GitHub-проект и проверить работоспособность исходной версии.
2. Исправить выбор области копания и точность Recorder / Replayer.
3. Встроить Task Queue + Emergency Stop + Macro Debugger + профили.
4. Профилировать текущую производительность. Реализовать собственный Chunk Update Budget, Particle Limiter и совместимость с Sodium.
5. Добавить Armor HUD, Custom Fog, Fullbright и Item Physics.
6. Добавить Shulker Preview и Container Preview без раскрытия серверных данных, которых клиент не знает.
7. Добавить Path Recorder, Ghost Replay, Waypoints, Loops, Conditions.
8. Добавить Auto Sort, Refill, Eat, Fish, Farm через общую очередь с подтверждением действий.
9. Добавить HUD Editor, Theme Manager, Timeline Editor и Route Editor.
10. Протестировать Fabric 1.21.11 с Sodium, без Sodium и при прерывании сессии.

## Запреты на интеграцию

- Не копировать Sodium в мод и не называть самостоятельную оптимизацию Sodium.
- Не подменять старый JAR новой недописанной сборкой.
- Не выполнять игровые действия в фоновых Java потоках.
- Не угадывать содержимое закрытых серверных контейнеров.
- Не запускать одновременно конкурирующие инвентарные операции.
