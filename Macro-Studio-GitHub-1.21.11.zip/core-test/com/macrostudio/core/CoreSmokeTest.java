package com.macrostudio.core;

import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicInteger;

public final class CoreSmokeTest {
    private static final class CountTask implements StudioTask {
        private final AtomicInteger ticks = new AtomicInteger();
        private boolean canceled;
        public String id() { return "demo"; }
        public TaskState tick() { return ticks.incrementAndGet() >= 2 ? TaskState.COMPLETED : TaskState.RUNNING; }
        public void cancel() { canceled = true; }
    }
    public static void main(String[] args) throws Exception {
        var queue = new TaskQueue();
        var task = new CountTask();
        queue.enqueue(task);
        queue.tick();
        if (queue.pendingCount() != 1) throw new AssertionError("task disappeared too early");
        queue.tick();
        if (queue.pendingCount() != 0) throw new AssertionError("task did not complete");
        var another = new CountTask();
        queue.enqueue(another);
        var released = new AtomicInteger();
        new EmergencyStop(queue, released::incrementAndGet).stopEverything();
        if (!another.canceled || released.get() != 1 || queue.pendingCount() != 0)
            throw new AssertionError("emergency stop failed");
        var profiler = new PerformanceProfiler();
        long start = profiler.start();
        profiler.record("demo", start);
        if (profiler.snapshot().get("demo").samples() != 1) throw new AssertionError("profiler failed");
        var path = Files.createTempDirectory("macro-studio-test").resolve("profiles.txt");
        var profiles = new MacroProfiles(path);
        if (!profiles.add("test_profile") || profiles.add("../unsafe")) throw new AssertionError("profile validation failed");
        profiles.save();
        var loaded = new MacroProfiles(path);
        loaded.load();
        if (!loaded.list().equals(java.util.List.of("test_profile"))) throw new AssertionError("profile load failed");
        if (ModuleCatalog.REQUESTED.size() != 30) throw new AssertionError("module count changed");
        System.out.println("PASS: queue, emergency stop, profiler, profile save, 30-module catalog");
    }
}
