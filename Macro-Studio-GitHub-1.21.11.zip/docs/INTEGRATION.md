# Integration into original Minecraft mod

## Phase 0 — Recover editable sources

The input archive does not include `src/`, Gradle wrapper or build scripts. `macro-studio-1.0.0.jar` is bytecode, not an editable source tree. Request the repository with the original project sources before changing game functionality. Do not overwrite or silently decompile the user's licensed mod.

Observed classes in original JAR: `com.macrostudio.Recorder`, `Replayer`, `Digger`, `Optimize`, `Deposit`, `MacroStudioScreen`, `Binds`, `Settings`, plus Mixins.

## First integration steps

1. Back up the source repository and create `refactor/core` branch.
2. Copy `core-src/com/macrostudio/core/` to `src/main/java/com/macrostudio/core/`.
3. Wire `TaskQueue.tick()` to the existing Fabric client tick handler. Keep Minecraft state on the client thread; core tasks must not directly access game state off-thread.
4. Wire `EmergencyStop.stopEverything()` to a dedicated keyboard binding and to disconnection/death/world-change hooks. Release all emulated keys and in-flight inventory actions in integration callback.
5. Connect `MacroProfiles` to existing `Recorder`/`Replayer`. Never replace the user's existing macro file format without migration.
6. Hook `PerformanceProfiler` only around Macro Studio operations; avoid claiming global FPS improvement without measurement.
7. Add in-game UI and module-specific implementations gradually with separate PRs.

## Required testing

- Fabric Java client 1.21.11 alone; with Sodium; if applicable with Iris.
- Cold start and configuration migration.
- Focus loss, death, world disconnect, dimension change.
- Key release on emergency stop.
- Inventory actions confirmed by server before next action.
- Recording accuracy in ticks; time-based and state-aware playback.
- Render stability and FPS / memory baseline versus new modules.

## Source-check outcome

The ZIP has a testable Java core, but **is not** a source rebuild of the existing mod. It cannot presently produce a new integrated Fabric JAR. This is intentional: inventing the old source files from a compiled archive would be unsafe and misleading.
