# Macro Studio — GitHub development package

Minecraft Java **1.21.11**, Fabric, Java 21.

> **Important:** The uploaded archive contained **only the compiled `macro-studio-1.0.0.jar`**, not the original Gradle project or Java source files. The original JAR is preserved **unchanged** here; the planned new modules are **not yet installed in that JAR**. Do not claim that this repository builds the original mod.

## What is inside

- `macro-studio-1.0.0.jar` — user's original Fabric client mod, preserved unchanged.
- `core-src/` — real, standalone **Java 21 source code** for a task queue, emergency stop, module catalog, macro profiles, and performance profiler. Integration into original Minecraft mod is still needed.
- `spec/` — technical acceptance criteria and implementation priority for 30 requested modules.
- `.github/workflows/core-check.yml` — GitHub Actions validation for standalone Java core.
- `scripts/verify-core.sh` — local Java core validation (Linux/macOS or Git Bash).
- `docs/INTEGRATION.md` — integration instructions and limitations.

## Upload this ZIP to GitHub

1. Create a new GitHub repository (or open your existing one).
2. Extract the ZIP to your computer. Upload **the extracted files** to the repository (GitHub does not unpack ZIP uploads automatically).
3. Commit and push. GitHub Actions will validate the standalone Java core.
4. When the real sources (`src/main/java`, `build.gradle`, `gradle.properties`, `fabric.mod.json`) are available, merge the new core code into that project, then wire it to Fabric events and actual Minecraft APIs.

**Do not put this whole ZIP in `.minecraft/mods`**. The original `macro-studio-1.0.0.jar` is the only directly installable mod file within this package.

## Modules

See `spec/modules.json` for all 30 requested modules, implementation order, dependencies, acceptance criteria, and status.

## Smoke test

```bash
bash scripts/verify-core.sh
```

No external Maven downloads are required for the smoke test; requires `javac` and `java` from JDK 21+.

## Sodium

Use Sodium as an **independent installed mod**. Compatibility should be provided by detecting it and avoiding interfering render Mixins, *not* bundling Sodium or copying its code.
