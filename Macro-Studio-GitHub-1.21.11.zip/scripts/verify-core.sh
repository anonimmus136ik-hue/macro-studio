#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/core-check
find core-src core-test -type f -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -d build/core-check
java -ea -cp build/core-check com.macrostudio.core.CoreSmokeTest
